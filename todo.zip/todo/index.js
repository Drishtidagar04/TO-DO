//acquiring the express
const { checkPrime } = require('crypto');
const express=require('express');
const flatpickr = require("flatpickr");
const app=express();
//creating the port
const path=require('path');
const port=8000;
//acquring the database
const db=require('./config/mongoose');
//getting the models
const TodoList=require('./models/todolist');
//function for validating the date
const {due_date_validate}=require('./routes/home');
//setting the view engine
app.set('view engine','ejs');
app.set('views',path.join(__dirname,'views') );
app.use(express.urlencoded());
// rendering static files
app.use(express.static('assets'));

//fetching the data from the database
app.get('/',function(req,res){
    TodoList.find({},function(err,todos){
        if(err){
            console.log('error in fetching contact from db');
        }
        return res.render('home',{
            title:"My Todo List",
            todo_list:todos
        });
    });
});
//adding or posting new data into the database
app.post('/create-todo',function(req,res){
        TodoList.create({
            name:req.body.item,
            due_date: due_date_validate(req.body.due_date),
            type:req.body.category
        },function(err, newTodo){
            if(err){
                console.log('error in creating a contact');
                return;
            }
            console.log('***********',newTodo);
            return res.redirect('back');
    
        });
});

//trying the updating part
// app.patch('/update-todo',function(req,res){
//     console.log(req.body.item);
//     TodoList.findByIdAndUpdate({
//         name:req.body.item,
//         due_date:due_date_validate(req.body.due_date),
//         type:req.body.category
//     },function(err,updateTodo){
//         if(err){
//             console.log('error in updating the data');
//         }
//         console.log('******update**',updateTodo);
//         return res.redirect('back');
//     });
     
// });

//deleting the data from the database
app.get('/delete-todo',function(req,res){
    //get the id from query
    var id=req.query;
    //checking the number of tasks selected to delete
    var count=Object.keys(id).length;
    for(let i=0;i<count;i++){
        //finding and deleting tasks from the DB one by one and using id
        TodoList.findByIdAndDelete(Object.keys(id)[i],function(err){
            if(err){
                console.log("error in deleting task");
            }
        });
    }
    return res.redirect('back');
    // let id=req.query.id;
    // console.log(id);
    // //find the conatact in the database using id and delete
    // TodoList.findByIdAndDelete(id, function(err){
    //     if(err){
    //         console.log('error in deleting an object from database');
    //         return;
    //     }
    //     return res.redirect('back');
    // });
});





//listining to the website
app.listen(port,function(err){
    if(err){
        console.log(`Error in running the server on ${port}`);
    }
    console.log(`Server is running on port ${port}`);
});