// getting started
const { verify } = require('crypto');
//connect to the database
const mongoose=require('mongoose');
// acquring the connection
mongoose.connect('mongodb://localhost/todo_list_db');

// verify if connected to databasde or not
const db = mongoose.connection;
// if error
db.on('error',console.error.bind(console,'error connecting to db'));
// up and running then print the message
db.once('open',function(){
    console.log('successfully connected to the database');
});
