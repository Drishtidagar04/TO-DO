const mongoose=require('mongoose');

//creating schema
const todoschema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    due_date:{
        type:String,
        default:"No Deadline",
        required:true
    },
    type:{
        type:String,
        required:true
    }

});

const todoList = mongoose.model('todoList',todoschema);
module.exports=todoList;