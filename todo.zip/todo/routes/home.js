console.log('js is accessed');
const due_date_validate=function (item_due_date){
    let date_full='';
    if(item_due_date==''){
        date_full="No Deadline";
    }else{
        var date=item_due_date.slice(8,10);
        var month=item_due_date.slice(5,7);
        var year=item_due_date.slice(0,4);
        var month_array=["JAN","FEB","MAR","APR","MAY","JUNE","JULY","AUG","SEP","OCT","NOV","DEC"];
        date_full=month_array[month-1]+" "+date+","+year;
    }
    
    return date_full;
}
module.exports={due_date_validate};