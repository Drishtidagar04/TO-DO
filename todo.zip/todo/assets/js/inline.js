console.log("hello i am js");
alert("hii");
